module awt_simple_application {
	requires java.desktop;
	requires java.sql;
}