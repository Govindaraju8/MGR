package skm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	final String url = "jdbc:postgresql://192.168.110.48:5432/plf_training";
	final String username = "plf_training_admin";
	final String password = "pff123";
	Connection conn = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.setContentType("text/html");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.getWriter().append("\n this is raju");
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, username, password);
			PrintWriter out = response.getWriter();
			if (conn == null) {
				out.println("Connected to the PostgreSQL database!");
				// Do your database operations here...
				// For example: execute queries, updates, etc.
				response.getWriter().append("\n this is raju");

			} else {
				out.println("Failed to connect to the database.");
			}
			response.getWriter().append("\n this is raju");
			String selectQuery = "SELECT * FROM Employee789";
			Statement stmt = conn.createStatement();
			// PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
			ResultSet resultSet = stmt.executeQuery(selectQuery);

			if (resultSet.next()) {
				int empNo = resultSet.getInt("empno");
				String empName = resultSet.getString("empname");
				String job = resultSet.getString("job");
				double salary = resultSet.getDouble("salary");
				String department = resultSet.getString("department");

				response.setContentType("text/html");
				out.println("<html><body>");

				out.println("<table>");
				out.println("<tr><td>Employee No:</td><td>" + empNo + "</td></tr>");
				out.println("<tr><td>Employee Name:</td><td>" + empName + "</td></tr>");
				out.println("<tr><td>Job Designation:</td><td>" + job + "</td></tr>");
				out.println("<tr><td>Salary:</td><td>" + salary + "</td></tr>");
				out.println("<tr><td>Department:</td><td>" + department + "</td></tr>");
				out.println("</table>");

				out.println("</body></html>");
			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
