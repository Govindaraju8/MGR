package govind;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class Employee789 {
	private int empNo;
	private String empName;
	private String job;
	private double salary;
	private String department;

	public Employee789(int empNo, String empName, String job, double salary, String department) {
		this.empNo = empNo;
		this.empName = empName;
		this.job = job;
		this.salary = salary;
		this.department = department;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	/*
	 * private ArrayList<Employee789> employees = new ArrayList<>();
	 * 
	 * protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	 * IOException {
	 * 
	 * try { String url = "jdbc:postgresql://192.168.110.48:5432/plf_training"; String username = "plf_training_admin";
	 * String password = "pff123"; Class.forName("org.postgresql.Driver");
	 * 
	 * Connection cn = DriverManager.getConnection(url, username, password); /* String selectQuery =
	 * "SELECT * FROM Employee789"; PreparedStatement selectStmt = cn.prepareStatement(selectQuery); ResultSet resultSet
	 * = selectStmt.executeQuery();
	 * 
	 * while (resultSet.next()) { Integer empno = resultSet.getInt("empno"); String empname
	 * =resultSet.getString("empname"); String job = resultSet.getString("job"); Double salary =
	 * resultSet.getDouble("salary"); String department = resultSet.getString("department"); Employee789 emp =new
	 * Employee789(empno, empname, job, salary, department); employees.add(emp); } HttpSession session =
	 * request.getSession(); session.setAttribute("employees", employees);
	 * 
	 * String action = request.getParameter("action");
	 * 
	 * if ("Add".equals(action)) { int empNo = Integer.parseInt(request.getParameter("empNo")); String empName =
	 * request.getParameter("empName"); String job = request.getParameter("job"); double salary =
	 * Double.parseDouble(request.getParameter("salary")); String department = request.getParameter("department");
	 * 
	 * Employee789 employee = new Employee789(empNo, empName, job, salary, department); employees.add(employee); String
	 * insertQuery = "INSERT INTO Employee789 (empno, empname, job, salary, department) VALUES (?, ?, ?, ?, ?)";
	 * PreparedStatement insertStmt = cn.prepareStatement(insertQuery); insertStmt.setInt(1, empNo);
	 * insertStmt.setString(2, empName); insertStmt.setString(3, job); insertStmt.setDouble(4, salary);
	 * insertStmt.setString(5, department); insertStmt.executeUpdate();
	 * 
	 * // You should perform database insertion here response.setContentType("application/json");
	 * response.setCharacterEncoding("UTF-8");
	 * response.getWriter().write("{\"message\": \"Employee added successfully\"}");
	 * 
	 * } else if ("Edit".equals(action)) { // Logic for editing an employee
	 * 
	 * } else if ("Del".equals(action)) { // Logic for deleting an employee
	 * 
	 * } else if ("Save".equals(action)) { // Logic for saving an employee
	 * 
	 * } else if ("Search".equals(action)) { // Logic for searching employees
	 * 
	 * } else if ("Clear".equals(action)) { // Logic for clearing fields
	 * 
	 * } else if ("Exit".equals(action)) { // Logic for exiting the application }
	 * 
	 * 
	 * // Redirect back to the HTML page // response.sendRedirect("home.html"); // Adjust the redirect path if needed
	 * 
	 * // You can implement doGet() and other methods for handling other HTTP requests
	 * 
	 * // Employee class with constructor, getters, setters, and other methods
	 * 
	 * // Database connectivity and CRUD operations can be added here cn.close(); } catch (Exception e) {
	 * e.printStackTrace(); } }
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		try {
			String url = "jdbc:postgresql://192.168.110.48:5432/plf_training";
			String username = "plf_training_admin";
			String password = "pff123";
			Class.forName("org.postgresql.Driver");

			Connection cn = DriverManager.getConnection(url, username, password);

			String selectQuery = "SELECT * FROM Employee789";
			PreparedStatement selectStmt = cn.prepareStatement(selectQuery);
			ResultSet resultSet = selectStmt.executeQuery();

			if (resultSet.next()) {
				int empNo = resultSet.getInt("empno");
				String empName = resultSet.getString("empname");
				String job = resultSet.getString("job");
				double salary = resultSet.getDouble("salary");
				String department = resultSet.getString("department");

				PrintWriter out = response.getWriter();
				out.println("<html><body>");

				// Display the retrieved data in the form fields
				out.println("<form action=\"EmployeeServlet\" method=\"POST\">");
				out.println("<label for=\"empNo\">Employee No:</label>");
				out.println("<input type=\"text\" name=\"empNo\" id=\"empNo\" placeholder=\"Employee No\" value=\""
						+ empNo + "\" required><br><br>");

				out.println("<label for=\"empName\">Employee Name:</label>");
				out.println(
						"<input type=\"text\" name=\"empName\" id=\"empName\" placeholder=\"Employee Name\" value=\""
								+ empName + "\" required><br><br>");

				out.println("<label for=\"job\">Job Designation:</label>");
				out.println("<input type=\"text\" name=\"job\" id=\"job\" placeholder=\"Job Designation\" value=\""
						+ job + "\" required><br><br>");

				out.println("<label for=\"salary\">Salary:</label>");
				out.println("<input type=\"text\" name=\"salary\" id=\"salary\" placeholder=\"Salary\" value=\""
						+ salary + "\" required><br><br>");

				out.println("<label for=\"department\">Department:</label>");
				out.println(
						"<input type=\"text\" name=\"department\" id=\"department\" placeholder=\"Department\" value=\""
								+ department + "\" required><br><br>");

				out.println("<select name=\"choice\" id=\"choice\">");
				out.println("<option value=\"view\">view</option>");
				out.println("<option value=\"edit\">edit</option>");
				out.println("<option value=\"add\">add</option>");
				out.println("<option value=\"del\">del</option>");
				out.println("</select>");

				// Add other buttons here

				out.println("<br>");
				out.println("<button type=\"submit\" id=\"firstbutton\">first</button>");
				// Add other buttons here

				out.println("</form>");

				out.println("</body></html>");
			}

			cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
