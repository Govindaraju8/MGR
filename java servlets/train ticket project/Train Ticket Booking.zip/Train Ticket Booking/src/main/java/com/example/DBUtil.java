package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getConnection() throws SQLException {
		String url="jdbc:postgresql://localhost:5432/postgres";
		String username="postgres";
		String password="Postgres";
        return DriverManager.getConnection(url, username, password);
    }

}
