package com.emp.govind;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/EmployeeSearchServlet")
public class EmployeeSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String url="jdbc:postgresql://localhost:5432/postgres";
    private static final String username="postgres";
    private static final String password="Postgres";
       
    
    public EmployeeSearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String empNo = request.getParameter("empNo");
            String empName = request.getParameter("empName");
            String deptNo = request.getParameter("deptNo");
            String salFrom = request.getParameter("salFrom");
            String salTo = request.getParameter("salTo");
            String job = request.getParameter("job");

            String query = "SELECT * FROM Employee WHERE 1=1 ";
            
            if (empNo != null && !empNo.isEmpty()) {
                query += "AND empno = " + empNo + " ";
            }
            if (empName != null && !empName.isEmpty()) {
                query += "AND empname LIKE '%" + empName + "%' ";
            }
            if (deptNo != null && !deptNo.isEmpty()) {
                query += "AND deptno = " + deptNo + " ";
            }
            if (salFrom != null && salTo != null && !salFrom.isEmpty() && !salTo.isEmpty()) {
                query += "AND sal BETWEEN " + salFrom + " AND " + salTo + " ";
            }
            if (job != null && !job.isEmpty()) {
                query += "AND jobrole LIKE '%" + job + "%' ";
            }

            try (Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(query)) {
                JSONArray jsonArray = new JSONArray();

                while (rs.next()) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("empno", rs.getInt("empno"));
                    jsonObject.put("empname", rs.getString("empname"));
                    jsonObject.put("deptno", rs.getInt("deptno"));
                    jsonObject.put("jobrole", rs.getString("jobrole"));
                    jsonObject.put("sal", rs.getDouble("sal"));
                    jsonArray.put(jsonObject);
                }

                PrintWriter out = response.getWriter();
                out.print(jsonArray.toString());
                out.flush();
            } catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String newEmpNo = request.getParameter("newEmpNo");
            String newEmpName = request.getParameter("newEmpName");
            String newDept = request.getParameter("newDept");
            String newJobRole = request.getParameter("newJobRole");
            String newSalary = request.getParameter("newSalary");

            String insertQuery = "INSERT INTO Employee (empno, empname, deptno, jobrole, sal) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                pstmt.setInt(1, Integer.parseInt(newEmpNo));
                pstmt.setString(2, newEmpName);
                pstmt.setInt(3, Integer.parseInt(newDept));
                pstmt.setString(4, newJobRole);
                pstmt.setDouble(5, Double.parseDouble(newSalary));
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
	}

}





