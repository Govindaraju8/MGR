public interface Transaction{

	public void deposit(double amt);

	public void withdraw(double amt);
}
	

	