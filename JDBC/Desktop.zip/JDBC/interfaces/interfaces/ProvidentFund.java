class ProvidentFund implements Transaction{

	//interface implemented method
	public void deposit(double amt){
			
			System.out.println("PF implementatn of deposit");
	}

	//interface implemented method
	public void withdraw(double amt){
			
			System.out.println("PF implementatn of wthdraw");
	}

	public void calPFAmount(){
		System.out.println("PF Amount calculatn");
	
	}
}