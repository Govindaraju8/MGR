package empcurdmvc;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the input values from request parameters
        String action = request.getParameter("action");
     // Create an instance of the DALclass
        DALclass empDAL = new DALclass();

        try {

            if ("first".equals(action)) {
                // Show first employee
                emp employee = empDAL.getFirstEmployee();
                request.setAttribute("employee", employee);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
                dispatcher.forward(request, response);
            }
            else if ("addEmployee".equals(action)) {
                // Get the input values from request parameters
                int empID = Integer.parseInt(request.getParameter("empID"));
                String empNo = request.getParameter("empNo");
                String jobRole = request.getParameter("jobRole");
                double salary = Double.parseDouble(request.getParameter("salary"));

                // Create an instance of the emp class
                emp employee = new emp(empID, empNo, jobRole, salary);

                // Call the insertEmployee method to insert the data
                empDAL.insertEmployee(employee);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
                dispatcher.forward(request, response);
                // Respond to the client indicating success
                //response.setContentType("text/html");
                //response.getWriter().println("Data inserted successfully!");
            } else if ("deleteEmployee".equals(action)) {
                int empIDToDelete = Integer.parseInt(request.getParameter("empID"));

                // Call the deleteEmployee method to delete the record
                empDAL.deleteEmployee(empIDToDelete);

                // Respond to the client indicating success
                RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
                dispatcher.forward(request, response);
                //response.setContentType("text/html");
                //response.getWriter().println("Employee record deleted successfully!");
            }
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions here
            response.setContentType("text/html");
            response.getWriter().println("Error: " + e.getMessage());
        }
        }
}
