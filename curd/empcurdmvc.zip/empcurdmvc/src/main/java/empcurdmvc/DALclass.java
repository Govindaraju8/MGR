package empcurdmvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DALclass {
	 private String url = "jdbc:postgresql://localhost:5432/postgres";
	    private String user = "postgres";
	    private String password = "Postgres";
	    Connection conn = null;
        PreparedStatement pstmt = null;
        
        
        public emp getFirstEmployee() throws ClassNotFoundException, SQLException {
            emp employee = null;
           // Connection conn = null;
            Statement st = null;
            ResultSet rs = null;

            try {
                // Establish the database connection

	            Class.forName("org.postgresql.Driver");
	            conn = DriverManager.getConnection(url, user, password);
                // Create a statement
                st = conn.createStatement();

                // Execute the query to get the first employee
                String query = "SELECT * FROM emp LIMIT 1";
                rs = st.executeQuery(query);

                // Process the result
                if (rs.next()) {
                    int empID = rs.getInt("empID");
                    String empNo = rs.getString("empNo");
                    String jobRole = rs.getString("jobRole");
                    double salary = rs.getDouble("salary");

                    // Create an emp object
                    employee = new emp(empID, empNo, jobRole, salary);
                }
            } catch(Exception e) {
                // Close resources
               
            }

            return employee;
        }
	    public void insertEmployee(emp employee) throws ClassNotFoundException, SQLException {
	        //Connection conn = null;
	        //PreparedStatement pstmt = null;

	        try {
	            Class.forName("org.postgresql.Driver");
	            conn = DriverManager.getConnection(url, user, password);

	            String insertQuery = "INSERT INTO emp (empid, ename, jobrole, sal) VALUES (?, ?, ?, ?)";
	            pstmt = conn.prepareStatement(insertQuery);
	            
	            pstmt.setInt(1, employee.getEmpid());
	            pstmt.setString(2, employee.getEname());
	            pstmt.setString(3, employee.getJobrole());
	            pstmt.setDouble(4, employee.getSal());
	            
	            pstmt.executeUpdate();
	        } finally {
	            if (pstmt != null) {
	                pstmt.close();
	            }
	            if (conn != null) {
	                conn.close();
	            }
	        }
	    }
	    
	    public void deleteEmployee(int empID) throws ClassNotFoundException, SQLException {
	        Connection conn = null;
	        PreparedStatement pstmt = null;

	        try {
	            String query = "DELETE FROM emp WHERE empid = ?";
	            Class.forName("org.postgresql.Driver");
	            conn = DriverManager.getConnection(url, user, password);
	            pstmt = conn.prepareStatement(query);
	            pstmt.setInt(1, empID);

	            pstmt.executeUpdate();
	        } finally {
	            // Close the resources
	            if (pstmt != null) {
	                pstmt.close();
	            }
	            if (conn != null) {
	                conn.close();
	            }
	        }
	    }

}
